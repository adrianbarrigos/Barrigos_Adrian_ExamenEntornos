package dao;


import java.math.BigDecimal;
import java.sql.Connection;
import java.util.ArrayList;
import java.sql.Date;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author absou
 */

public class PedidosDaoTest {
    
    public PedidosDaoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getConexion method, of class PedidosDao.
     */
    @Test
    public void testGetConexion() {
        
        PedidosDao instance= new PedidosDao();
        Connection expected = instance.getConexion();
        Connection resultado = null;
        
        assertNotEquals(resultado,expected);
    }

    /**
     * Test of read method, of class PedidosDao.
     */
    @Test
    public void testRead() {
        
        PedidosDao instance= new PedidosDao();
        Pedido expected = instance.read(10248);
        Pedido resultado = instance.read(10248);
        assertEquals(resultado.getId(),expected.getId());
        assertEquals(resultado.getCliente_id(),expected.getCliente_id());
        assertEquals(resultado.getEmpleado_id(),expected.getEmpleado_id());
        
        Pedido expected1= null;
        Pedido resultado1= instance.read(1321321321);
        assertEquals(expected1,resultado1);
    }

    /**
     * Test of insert method, of class PedidosDao.
     */
    @Test
    public void testInsert() {
        
        PedidosDao instance= new PedidosDao();
        Date fecha1 = new Date(1996-07-04);
        Date fecha2 = new Date(1996-06-01);
        Date fecha3 = new Date(1996-07-16);
        BigDecimal cargo = new BigDecimal(32.3800);
        
        Pedido pedido = new Pedido(11078, 80, 5, fecha1, fecha2, fecha3, 3, cargo, "test", "test", "test", "test", "test", "test");
        Integer expected= 0;
        Integer resultado= instance.insert(pedido);
        assertNotEquals(expected, resultado);
        instance.delete(resultado);
        
        //envio Error
        Pedido pedidoE = new Pedido(11078, 80, 5, fecha1, fecha2, fecha3, 6, cargo, "test", "test", "test", "test", "test", "test");
        Integer expectedE= null;
        Integer resultadoE= instance.insert(pedidoE);
        assertEquals(expectedE, resultadoE);
        
    }

    /**
     * Test of update method, of class PedidosDao.
     */
    @Test
    public void testUpdate() {
        
        PedidosDao instance= new PedidosDao();
        Date fecha1 = new Date(1996-07-04);
        Date fecha2 = new Date(1996-06-01);
        Date fecha3 = new Date(1996-07-16);
        BigDecimal cargo = new BigDecimal(32.3800);
        Pedido pedido = new Pedido(11078, 80, 5, fecha1, fecha2, fecha3, 3, cargo, "test", "test", "test", "test", "test", "test");
        Integer resultadoInsert= instance.insert(pedido);
        
        Pedido nuevopedido = new Pedido(resultadoInsert, 80, 7, fecha1, fecha2, fecha3, 3, cargo, "test", "test", "test", "test", "test", "test");
        Integer expected= 1;
        Integer resultado= instance.update(nuevopedido);
        assertEquals(expected, resultado);
        
        //fallo
        Pedido pedidoF = new Pedido(11078, 80, 8, fecha1, fecha2, fecha3, 4, cargo, "test", "test", "test", "test", "test", "test");
        Integer expectedF= 0;
        Integer resultadoF= instance.update(pedidoF);
        assertEquals(expectedF, resultadoF);
        instance.delete(resultadoInsert);
        
        
    }

    /**
     * Test of delete method, of class PedidosDao.
     */
    @Test
    public void testDelete() {
        
        PedidosDao instance= new PedidosDao();
        Date fecha1 = new Date(1996-07-04);
        Date fecha2 = new Date(1996-06-01);
        Date fecha3 = new Date(1996-07-16);
        BigDecimal cargo = new BigDecimal(32.3800);
        
        Pedido pedido = new Pedido(11078, 80, 5, fecha1, fecha2, fecha3, 3, cargo, "test", "test", "test", "test", "test", "test");
        Integer borrar = instance.insert(pedido);
        Integer expected= 1;
        Integer resultado= instance.delete(borrar);
        assertEquals(expected, resultado);
        
        //Fallo
        expected= 1;
        resultado= instance.delete(10249);
        assertEquals(expected, resultado);
    }

    /**
     * Test of listar method, of class PedidosDao.
     */
    @Test
    public void testListar() {
        
        PedidosDao instance= new PedidosDao();
        
        Integer pos = 1;
        ArrayList<Pedido> expected = null;
        ArrayList<Pedido> resultado = instance.listar(pos);
        assertNotEquals(expected,resultado);
        
    }
    
}
